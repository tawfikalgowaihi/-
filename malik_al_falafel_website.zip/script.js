// عدّل الرقم أدناه إلى رقم واتساب المحل بصيغة دولية دون + أو مسافات.
const WHATSAPP_NUMBER = "967XXXXXXXXX";

const products = [
  {id:"item1", name:"تشكن فرايز", price:2000, icon:"🍗🍟", category:"food"},
  {id:"item2", name:"فلافل ملكي", price:1000, icon:"🧆👑", category:"food"},
  {id:"item3", name:"فلافل عادي", price:500, icon:"🧆", category:"food"},
  {id:"item4", name:"زنجر ملكي", price:1300, icon:"🍔👑", category:"food"},
  {id:"item5", name:"زنجر عادي", price:1000, icon:"🍔", category:"food"},
  {id:"item6", name:"شاورما صاروخ", price:1000, icon:"🌯🚀", category:"food"},
  {id:"item7", name:"شاورما عادي", price:500, icon:"🌯", category:"food"},
  {id:"item8", name:"طعمية", price:300, icon:"🧆", category:"food"},
  {id:"item9", name:"عصير مشكل", price:1000, icon:"🍹", category:"drink"},
  {id:"item10", name:"سانكويك", price:500, icon:"🥤", category:"drink"},
  {id:"item11", name:"مانجو طبيعي", price:500, icon:"🥭", category:"drink"},
  {id:"item12", name:"عصير ليمون", price:500, icon:"🍋", category:"drink"},
  {id:"item13", name:"فينتو", price:500, icon:"🍷", category:"drink"}
];

const quantities = Object.fromEntries(products.map(p => [p.id, 0]));
let chipsAmount = 0;
let toastTimer;

const formatMoney = value => `${Number(value).toLocaleString("en-US")} ريال`;
const productById = id => products.find(p => p.id === id);

function renderMenu() {
  const foodGrid = document.getElementById("food-grid");
  const drinksGrid = document.getElementById("drinks-grid");
  foodGrid.innerHTML = "";
  drinksGrid.innerHTML = "";

  products.forEach((product, index) => {
    const card = document.createElement("article");
    card.className = "menu-card";
    card.style.animationDelay = `${Math.min(index * 45, 350)}ms`;
    card.innerHTML = `
      <div class="food-emoji" aria-hidden="true">${product.icon}</div>
      <h3>${product.name}</h3>
      <div class="price-pill">${formatMoney(product.price)}</div>
      <div class="qty-control">
        <button class="qty-btn" type="button" aria-label="تقليل ${product.name}" data-action="minus" data-id="${product.id}">−</button>
        <span class="qty-number" id="qty-${product.id}">0</span>
        <button class="qty-btn plus" type="button" aria-label="زيادة ${product.name}" data-action="plus" data-id="${product.id}">+</button>
      </div>`;
    (product.category === "food" ? foodGrid : drinksGrid).appendChild(card);
  });

  const chips = document.createElement("article");
  chips.className = "menu-card custom-card";
  chips.innerHTML = `
    <div><div class="food-emoji" aria-hidden="true">🍟</div><h3>شبس (حسب الطلب)</h3>
      <span class="cart-line-sub">اكتب المبلغ الذي تريده</span></div>
    <div class="custom-side">
      <input id="chips-amount" type="number" min="1" step="50" inputmode="numeric" placeholder="السعر بالريال" aria-label="سعر الشبس">
      <div class="qty-control">
        <button class="qty-btn" type="button" id="clear-chips" aria-label="مسح سعر الشبس">×</button>
        <span class="qty-number" id="qty-chips">0 ريال</span>
        <button class="qty-btn plus" type="button" id="add-chips" aria-label="إضافة الشبس">+</button>
      </div>
    </div>`;
  foodGrid.appendChild(chips);
  document.getElementById("chips-amount").addEventListener("input", () => {});
  document.getElementById("add-chips").addEventListener("click", addCustomChips);
  document.getElementById("clear-chips").addEventListener("click", clearCustomChips);
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}

function addToCart(id) {
  if (!Object.prototype.hasOwnProperty.call(quantities, id)) return;
  quantities[id] += 1;
  updateCart();
  showToast(`تمت إضافة ${productById(id).name} إلى السلة`);
}

function removeFromCart(id) {
  if (!Object.prototype.hasOwnProperty.call(quantities, id)) return;
  quantities[id] = Math.max(0, quantities[id] - 1);
  updateCart();
}

function addCustomChips() {
  const input = document.getElementById("chips-amount");
  const value = Number(input.value);
  if (!Number.isFinite(value) || value <= 0) {
    showToast("اكتب سعر الشبس أولاً");
    input.focus();
    return;
  }
  chipsAmount += Math.round(value);
  document.getElementById("qty-chips").textContent = formatMoney(chipsAmount);
  input.value = "";
  updateCart();
  showToast("تمت إضافة الشبس إلى السلة");
}

function clearCustomChips() {
  chipsAmount = 0;
  document.getElementById("qty-chips").textContent = "0 ريال";
  updateCart();
  showToast("تم مسح مبلغ الشبس");
}

function getItemsTotal() {
  return products.reduce((sum, product) => sum + product.price * quantities[product.id], 0) + chipsAmount;
}

function getDeliveryCost() {
  const select = document.getElementById("delivery-zone");
  const option = select.options[select.selectedIndex];
  return option && option.value ? Number(option.dataset.price || 0) : 0;
}

function getItemCount() {
  return products.reduce((sum, product) => sum + quantities[product.id], 0) + (chipsAmount > 0 ? 1 : 0);
}

function updateCart() {
  products.forEach(product => {
    const qty = document.getElementById(`qty-${product.id}`);
    if (qty) qty.textContent = quantities[product.id];
  });

  const lines = [];
  products.forEach(product => {
    const quantity = quantities[product.id];
    if (quantity > 0) {
      lines.push({name:product.name, quantity, total:product.price * quantity, unit:product.price, id:product.id});
    }
  });
  if (chipsAmount > 0) lines.push({name:"شبس حسب الطلب", quantity:1, total:chipsAmount, unit:chipsAmount, id:"chips"});

  const cartLines = document.getElementById("cart-lines");
  const cartEmpty = document.getElementById("cart-empty");
  cartLines.innerHTML = "";
  cartEmpty.classList.toggle("hidden", lines.length > 0);

  lines.forEach(line => {
    const row = document.createElement("div");
    row.className = "cart-line";
    const name = document.createElement("div");
    name.innerHTML = `<span class="cart-line-name"></span><span class="cart-line-sub"></span>`;
    name.querySelector(".cart-line-name").textContent = line.name;
    name.querySelector(".cart-line-sub").textContent = line.id === "chips" ? "مبلغ مخصص" : `${line.quantity} × ${formatMoney(line.unit)}`;
    const price = document.createElement("strong");
    price.className = "cart-line-price";
    price.textContent = formatMoney(line.total);
    const remove = document.createElement("button");
    remove.className = "cart-line-remove";
    remove.type = "button";
    remove.textContent = "×";
    remove.setAttribute("aria-label", `حذف ${line.name}`);
    remove.addEventListener("click", () => {
      if (line.id === "chips") clearCustomChips();
      else { quantities[line.id] = 0; updateCart(); }
    });
    row.append(name, price, remove);
    cartLines.appendChild(row);
  });

  const itemsTotal = getItemsTotal();
  const deliveryCost = getDeliveryCost();
  document.getElementById("items-total").textContent = formatMoney(itemsTotal);
  document.getElementById("delivery-cost").textContent = formatMoney(deliveryCost);
  document.getElementById("final-total").textContent = formatMoney(itemsTotal + deliveryCost);
  document.getElementById("cart-count").textContent = getItemCount();
  document.getElementById("wa-count").textContent = getItemCount();
}

function updatePaymentNotice() {
  const method = document.getElementById("payment-method").value;
  document.getElementById("bank-warning").classList.toggle("hidden", method === "الدفع عند الاستلام كاش");
}

function buildOrderMessage() {
  const lines = ["👑 *طلب جديد - ملك الفلافل*", "━━━━━━━━━━━━━━"];
  products.forEach(product => {
    const quantity = quantities[product.id];
    if (quantity > 0) lines.push(`• ${product.name} × ${quantity} = ${formatMoney(product.price * quantity)}`);
  });
  if (chipsAmount > 0) lines.push(`• شبس حسب الطلب = ${formatMoney(chipsAmount)}`);
  lines.push("━━━━━━━━━━━━━━");
  lines.push(`إجمالي الأصناف: ${formatMoney(getItemsTotal())}`);
  lines.push(`منطقة التوصيل: ${document.getElementById("delivery-zone").value}`);
  lines.push(`التوصيل: ${formatMoney(getDeliveryCost())}`);
  lines.push(`*الإجمالي الكلي: ${formatMoney(getItemsTotal() + getDeliveryCost())}*`);
  lines.push(`العنوان: ${document.getElementById("exact-address").value.trim()}`);
  const name = document.getElementById("customer-name").value.trim();
  const phone = document.getElementById("customer-phone").value.trim();
  const notes = document.getElementById("order-notes").value.trim();
  if (name) lines.push(`اسم المستلم: ${name}`);
  if (phone) lines.push(`رقم التواصل: ${phone}`);
  lines.push(`طريقة الدفع: ${document.getElementById("payment-method").value}`);
  if (notes) lines.push(`ملاحظات: ${notes}`);
  lines.push("الرجاء تأكيد الطلب ووقت التوصيل.");
  return lines.join("\n");
}

function sendOrder() {
  if (getItemCount() === 0) {
    showToast("أضف صنفاً واحداً على الأقل قبل إرسال الطلب");
    return;
  }
  const zone = document.getElementById("delivery-zone").value;
  const address = document.getElementById("exact-address").value.trim();
  if (!zone) {
    showToast("اختر منطقة التوصيل أولاً");
    document.getElementById("delivery-zone").focus();
    return;
  }
  if (!address) {
    showToast("اكتب العنوان الدقيق لتوصيل طلبك");
    document.getElementById("exact-address").focus();
    return;
  }
  if (!/^\d{8,15}$/.test(WHATSAPP_NUMBER)) {
    showToast("ضع رقم واتساب المحل الصحيح داخل ملف script.js أولاً");
    return;
  }
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(buildOrderMessage())}`;
  window.open(url, "_blank", "noopener,noreferrer");
}

document.addEventListener("click", event => {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const id = button.dataset.id;
  if (button.dataset.action === "plus") addToCart(id);
  if (button.dataset.action === "minus") removeFromCart(id);
});

document.getElementById("delivery-zone").addEventListener("change", updateCart);
document.getElementById("payment-method").addEventListener("change", updatePaymentNotice);
document.getElementById("submit-order").addEventListener("click", sendOrder);
document.getElementById("whatsapp-float").addEventListener("click", event => {
  event.preventDefault();
  document.getElementById("checkout").scrollIntoView({behavior:"smooth", block:"start"});
  showToast("أكمل اختيار الأصناف والعنوان ثم أرسل الطلب");
});

renderMenu();
updateCart();
updatePaymentNotice();
